package net.androidbootcamp.classstuff;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private String Name;
    private Integer PhoneNumber;
    private String Email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.btnContacts); // create two instances of two buttons.
        Button button1 = (Button) findViewById(R.id.btnContacts2);

        button.setOnClickListener(new View.OnClickListener() { // button event handler
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ContactB.class));
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ContactA.class));
            }
        });
    }
}